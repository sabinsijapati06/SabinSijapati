Cave Diver Pathfinding Visualizer
Coursework by Sabin Sijapati. Original course code; retain attribution in source files.
Searches down and right recursively, checks cell depth, and highlights the successful path.
