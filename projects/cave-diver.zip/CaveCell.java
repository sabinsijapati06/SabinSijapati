import java.awt.*;

public class CaveCell {
    
    private static final int minDepth = 1;
    private static final int maxDepth = 10;
    private static final Color escpColor = new Color(242, 0, 0);

    // attributes
    private int row;
    private int col;
    private int depth;
    private boolean escpRoutePart; // Part of Escape Route

    /**
     * cell with its position and a random depth
     * @param row row position in the grid
     * @param col column position in the grid
     */
    public CaveCell(int row, int col) {
        this.row = row;
        this.col = col;
        this.depth = genRandDepth();
        this.escpRoutePart = false;
    }

    /**
     * generates random depth value
     * 
     * @return random depth value
     */
    private int genRandDepth() {
        return (int) (Math.random() * (maxDepth - minDepth + 1) + minDepth);
    }

    /**
     * depth of the cell
     * @return depth value
     */
    public int getDepth() {
        return depth;
    }

    /**
     * whether this cell is part of the escape route
     * @param partOfEscapeRoute true if part of the escape route, false otherwise
     */
    public void escpRoutePart(boolean partOfEscapeRoute) {
        this.escpRoutePart = partOfEscapeRoute;
    }

    /**
     * deeper cells are darker blue, shallower cells are lighter blue
     * @return color to use for the cell
     */
    private Color depthColor() {
        
        int blueValue = 255 - ((depth - 1) * 20);
        return new Color(0, 0, blueValue);
    }

    /**
     * paints the cell
     * @param g Graphics object to paint on
     * @param x x-coordinate of the top-left corner
     * @param y y-coordinate of the top-left corner
     * @param width width of the cell
     * @param height height of the cell
     */
    public void paint(Graphics g, int x, int y, int width, int height) {
        
        if (escpRoutePart) {
            g.setColor(escpColor);
        } else {
            g.setColor(depthColor());
        }

        g.fillRect(x, y, width, height);
        g.setColor(Color.WHITE);

        String depthStr = Integer.toString(depth);
        FontMetrics fm = g.getFontMetrics();

        int textX = x + (width - fm.stringWidth(depthStr)) / 2;
        int textY = y + (height + fm.getAscent()) / 2;
        
        g.drawString(depthStr, textX, textY);
    }
}