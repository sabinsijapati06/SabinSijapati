import java.awt.*;
import javax.swing.*;

public class Cave extends JComponent {
    private static final int gridSize = 10;
    private static final int maxAir = 20;
    private static final Color escpColor = new Color(242, 0, 0);
    private CaveCell[][] grid;
    public Cave() {
        grid = new CaveCell[gridSize][gridSize];
        genNewCave();
    }

    /**
     * generates a new random cave configuration
     */
    public void genNewCave() {
        for (int row = 0; row < gridSize; row++) {
            for (int col = 0; col < gridSize; col++) {
                grid[row][col] = new CaveCell(row, col);
            }
        }
        resetEscpRoute();
    }

    /**
     * resets the escape route flags for all cells
     */
    public void resetEscpRoute() {
        for (int row = 0; row < gridSize; row++) {
            for (int col = 0; col < gridSize; col++) {
                if (grid[row][col] != null) {
                    grid[row][col].escpRoutePart(false);
                }
            }
        }
    }

    /**
     * trying to find an escape route from the upper-left to the lower-right corner
     * using a recursive algorithm
     * @param depthRating maximum depth the diver can handle
     * @return true if an escape route is found
     */
    public boolean findEscapeRoute(int depthRating) {
        return findEscpRoute(0, 0, depthRating, maxAir);
    }

    /**
     * method to find an escape route
     * @param row current row
     * @param col current column
     * @param depthRating maximum depth the diver can handle
     * @param airRemaining amount of air left
     * @return true if an escape route is found
     */
    private boolean findEscpRoute(int row, int col, int depthRating, int airRemaining) {

        if (row >= gridSize || col >= gridSize) {
            return false;
        }
        
        if (grid[row][col].getDepth() > depthRating) {
            return false;
        }
        if (airRemaining <= 0) {
            return false;
        }
        
        if (row == gridSize - 1 && col == gridSize - 1) {
            grid[row][col].escpRoutePart(true);
            return true;
        }
        
        if (findEscpRoute(row + 1, col, depthRating, airRemaining - 1)) {
            grid[row][col].escpRoutePart(true);
            return true;
        }
        
        if (findEscpRoute(row, col + 1, depthRating, airRemaining - 1)) {
            grid[row][col].escpRoutePart(true);
            return true;
        }
        
        return false;
    }

    /**
     * paint the cave grid
     * @param g the Graphics object to paint on
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int width = getWidth();
        int height = getHeight();

        int cellWidth = width / gridSize;
        int cellHeight = height / gridSize;

        for (int row = 0; row < gridSize; row++) {
            for (int col = 0; col < gridSize; col++) {
                int x = col * cellWidth;
                int y = row * cellHeight;
                grid[row][col].paint(g, x, y, cellWidth, cellHeight);
            }
        }
    }

    /**
     * returns the preferred size of the component
     * @return the preferred size
     */
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(500, 500);
    }
}