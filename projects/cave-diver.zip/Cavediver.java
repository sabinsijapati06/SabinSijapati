import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Sabin Sijapati
 * @version 1.0
 */
public class Cavediver extends JFrame {
    private static final int windWidth = 600;
    private static final int windHeight = 700;
    private static final String windTitle = "Cave Diver - Find an Escape Route";
    private static final String textIntro = "The diver begins in the upper-left corner and escapes by reaching the lower-right corner.";
    private static final String depthLable = "Enter the diver's depth rating:";
    private static final String escpBottom = "Escape";
    private static final String newBottomCave = "New Cave";
    private static final String noescpTitle = "Ouch";
    private static final String noescpMsg = "No escape route found!";
    private static final int maxAir = 20;

    private JLabel introLabel;
    private JTextField depthField;
    private JButton escapeButton;
    private JButton newCaveButton;
    private Cave cave;

    /**
     * sets up the user interface and initializes the cave
     */
    public Cavediver() {

        setTitle(windTitle);
        setSize(windWidth, windHeight);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        introLabel = new JLabel(textIntro);
        introLabel.setHorizontalAlignment(JLabel.CENTER);
        introLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(introLabel, BorderLayout.NORTH);

        cave = new Cave();
        add(cave, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel();
        JLabel depthLabel = new JLabel(depthLable);
        depthField = new JTextField(5);
        escapeButton = new JButton(escpBottom);
        newCaveButton = new JButton(newBottomCave);

        bottomPanel.add(depthLabel);
        bottomPanel.add(depthField);
        bottomPanel.add(escapeButton);
        bottomPanel.add(newCaveButton);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(bottomPanel, BorderLayout.SOUTH);

        escapeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findEscapeRoute();
            }
        });

        newCaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateNewCave();
            }
        });
    }

    /**
     * attempts to find an escape route for the diver
     * displays the route if found, or shows an error message if not
     */
    private void findEscapeRoute() {
        try {
            int depthRating = Integer.parseInt(depthField.getText().trim());
            cave.resetEscpRoute();
            boolean routeFound = cave.findEscapeRoute(depthRating);
            if (!routeFound) {
                JOptionPane.showMessageDialog(this, noescpMsg, noescpTitle, JOptionPane.ERROR_MESSAGE);
            }
            cave.repaint();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid depth rating (1-10)", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * generates a new random cave configuration.
     */
    private void generateNewCave() {
        depthField.setText("");
        cave.genNewCave();
        cave.repaint();
    }
    public static void main(String[] args) {
        // create and show application window
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Cavediver caveDiv = new Cavediver();
                caveDiv.setVisible(true);
            }
        });
    }
}