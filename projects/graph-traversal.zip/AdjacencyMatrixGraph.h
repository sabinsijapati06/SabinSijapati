// Programming Problem 1 -- adjacency matrix implementation.
#ifndef ADJACENCY_MATRIX_GRAPH_H
#define ADJACENCY_MATRIX_GRAPH_H

#include "FlexibleAdjacencyMatrixGraph.h"
#include "GraphInterface.h"

#include <ostream>

template<class LabelType>
class AdjacencyMatrixGraph : public GraphInterface<LabelType>{
public:
AdjacencyMatrixGraph()
    : graph_(false, true){
}

int getNumVertices() const override{
    return graph_.getNumVertices();
}

int getNumEdges() const override{
    return graph_.getNumEdges();
}

void addVertex(LabelType label){
    graph_.addVertex(label);
}

bool add(LabelType start, LabelType end, int edgeWeight) override{
    return graph_.add(start, end, edgeWeight);
}

bool remove(LabelType start, LabelType end) override{
    return graph_.remove(start, end);
}

int getEdgeWeight(LabelType start, LabelType end) const override{
    return graph_.getEdgeWeight(start, end);
}

void depthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    graph_.depthFirstTraversal(start, visit);
}

void breadthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    graph_.breadthFirstTraversal(start, visit);
}

void printAdjacencyMatrix(std::ostream& out) const{
    graph_.printAdjacencyMatrix(out);
}

private:
FlexibleAdjacencyMatrixGraph<LabelType> graph_;
};

#endif
