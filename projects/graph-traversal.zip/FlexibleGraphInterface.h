/** An interface for matrix/list graphs that can be directed or undirected
    and weighted or unweighted. */

#ifndef FLEXIBLE_GRAPH_INTERFACE_H
#define FLEXIBLE_GRAPH_INTERFACE_H

template<class LabelType>
class FlexibleGraphInterface{
public:
virtual int getNumVertices() const = 0;
virtual int getNumEdges() const = 0;
virtual bool isDirected() const = 0;
virtual bool isWeighted() const = 0;
virtual bool add(LabelType start, LabelType end, int edgeWeight = 1) = 0;
virtual bool remove(LabelType start, LabelType end) = 0;
virtual bool hasEdge(LabelType start, LabelType end) const = 0;
virtual int getEdgeWeight(LabelType start, LabelType end) const = 0;
virtual void depthFirstTraversal(LabelType start, void visit(LabelType&)) = 0;
virtual void breadthFirstTraversal(LabelType start, void visit(LabelType&)) = 0;
virtual ~FlexibleGraphInterface() { }
};

#endif
