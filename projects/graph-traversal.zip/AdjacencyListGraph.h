// Programming Problem 2 -- adjacency list implementation.
#ifndef ADJACENCY_LIST_GRAPH_H
#define ADJACENCY_LIST_GRAPH_H

#include "FlexibleAdjacencyListGraph.h"
#include "GraphInterface.h"

#include <ostream>

template<class LabelType>
class AdjacencyListGraph : public GraphInterface<LabelType>
{
public:
AdjacencyListGraph()
    : graph_(false, true){
}

int getNumVertices() const override{
    return graph_.getNumVertices();
}

int getNumEdges() const override{
    return graph_.getNumEdges();
}

void addVertex(LabelType label){
    graph_.addVertex(label);
}

bool add(LabelType start, LabelType end, int edgeWeight) override{
    return graph_.add(start, end, edgeWeight);
}

bool remove(LabelType start, LabelType end) override{
    return graph_.remove(start, end);
}

int getEdgeWeight(LabelType start, LabelType end) const override{
    return graph_.getEdgeWeight(start, end);
}

void depthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    graph_.depthFirstTraversal(start, visit);
}

void breadthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    graph_.breadthFirstTraversal(start, visit);
}

void printAdjacencyList(std::ostream& out) const{
    graph_.printAdjacencyList(out);
}

private:
FlexibleAdjacencyListGraph<LabelType> graph_;
};

#endif
