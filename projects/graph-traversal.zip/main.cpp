// Topic 10 Homework - Programming Problem 1,2 & 3
// Name : Sabin Sijapati
// Course Section: CIS 2207 501
// Date: 04/19/2026
// This driver program demonstrates all three programming problems from
// Chapter 20 of the textbook using the exact graphs shown in the assigned
// figures (20-7 through 20-10) that we were asked to study carefully.
// Problem 1: AdjacencyMatrixGraph -- undirected, weighted graph stored
//            as an adjacency matrix (Figure 20-8).
// Problem 2: AdjacencyListGraph -- same undirected, weighted graph stored
//            as an adjacency list (Figure 20-10).
// Problem 3: FlexibleAdjacencyMatrixGraph and FlexibleAdjacencyListGraph --
//            the directed, unweighted graph from Figure 20-7 and 20-9,
//            showing how the same graph can be either directed or undirected
//            and either weighted or unweighted depending on configuration.
// Each section prints the graph structure and runs both DFS and BFS
// so the traversal order can be compared against the textbook examples.
#include "AdjacencyListGraph.h"
#include "AdjacencyMatrixGraph.h"
#include "FlexibleAdjacencyListGraph.h"
#include "FlexibleAdjacencyMatrixGraph.h"

#include <iostream>
#include <string>

using namespace std;

void visitLabel(string& label){
cout << label << ' ';
}

template<class GraphType>
void loadFigure207Vertices(GraphType& graph){
graph.addVertex("P");
graph.addVertex("Q");
graph.addVertex("R");
graph.addVertex("S");
graph.addVertex("T");
graph.addVertex("W");
graph.addVertex("X");
graph.addVertex("Y");
graph.addVertex("Z");
}

template<class GraphType>
void loadFigure207(GraphType& graph){
graph.add("P", "R", 1);
graph.add("P", "W", 1);
graph.add("Q", "X", 1);
graph.add("R", "X", 1);
graph.add("S", "T", 1);
graph.add("T", "W", 1);
graph.add("W", "S", 1);
graph.add("W", "Y", 1);
graph.add("Y", "R", 1);
graph.add("Y", "Z", 1);
}

template<class GraphType>
void loadFigure208Vertices(GraphType& graph){
graph.addVertex("A");
graph.addVertex("B");
graph.addVertex("C");
graph.addVertex("D");
}

template<class GraphType>
void loadFigure208(GraphType& graph){
graph.add("A", "B", 8);
graph.add("A", "D", 6);
graph.add("B", "C", 9);
}

template<class GraphType>
void showTraversals(const string& startLabel, GraphType& graph){
cout << "DFS from " << startLabel << ": ";
graph.depthFirstTraversal(startLabel, visitLabel);
cout << "\n";

cout << "BFS from " << startLabel << ": ";
graph.breadthFirstTraversal(startLabel, visitLabel);
cout << "\n";
}

void showDivider(){
cout << "----------------------------------------\n";
}

int main(){
AdjacencyMatrixGraph<string> figure208Matrix;
loadFigure208Vertices(figure208Matrix);
loadFigure208(figure208Matrix);

cout << "Figure 20-8 / Problem 1 adjacency matrix\n";
cout << "Directed: no\n";
cout << "Weighted: yes\n";
figure208Matrix.printAdjacencyMatrix(cout);
showTraversals("A", figure208Matrix);
showDivider();

AdjacencyListGraph<string> figure210List;
loadFigure208Vertices(figure210List);
loadFigure208(figure210List);

cout << "Figure 20-10 / Problem 2 adjacency list\n";
cout << "Directed: no\n";
cout << "Weighted: yes\n";
figure210List.printAdjacencyList(cout);
showTraversals("A", figure210List);

FlexibleAdjacencyMatrixGraph<string> figure207Matrix(true, false);
loadFigure207Vertices(figure207Matrix);
loadFigure207(figure207Matrix);

cout << "Figure 20-7 / Problem 3 matrix example\n";
cout << "Directed: yes\n";
cout << "Weighted: no\n";
figure207Matrix.printAdjacencyMatrix(cout);
showTraversals("P", figure207Matrix);
showDivider();

FlexibleAdjacencyListGraph<string> figure209List(true, false);
loadFigure207Vertices(figure209List);
loadFigure207(figure209List);

cout << "Figure 20-9 / Problem 3 adjacency list\n";
cout << "Directed: yes\n";
cout << "Weighted: no\n";
figure209List.printAdjacencyList(cout);
showTraversals("P", figure209List);
showDivider();

return 0;
}
