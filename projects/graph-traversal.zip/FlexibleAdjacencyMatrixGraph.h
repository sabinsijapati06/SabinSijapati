// Programming Problem 3 (matrix version) -- configurable adjacency matrix.
#ifndef FLEXIBLE_ADJACENCY_MATRIX_GRAPH_H
#define FLEXIBLE_ADJACENCY_MATRIX_GRAPH_H

#include "FlexibleGraphInterface.h"

#include <algorithm>
#include <cstddef>
#include <iomanip>
#include <map>
#include <ostream>
#include <queue>
#include <vector>

template<class LabelType>
class FlexibleAdjacencyMatrixGraph : public FlexibleGraphInterface<LabelType>{
public:
explicit FlexibleAdjacencyMatrixGraph(bool directed = false, bool weighted = true)
    : directed_(directed),
    weighted_(weighted),
    edgeCount_(0){
    }

int getNumVertices() const override{
    return static_cast<int>(labels_.size());
}

int getNumEdges() const override{
    return edgeCount_;
}

bool isDirected() const override{
    return directed_;
}

bool isWeighted() const override{
    return weighted_;
}

void addVertex(LabelType label){
    ensureVertex(label);
}

bool add(LabelType start, LabelType end, int edgeWeight = UNWEIGHTED_EDGE_WEIGHT) override{
    const std::size_t startIndex = ensureVertex(start);
    const std::size_t endIndex = ensureVertex(end);
    const int storedWeight = weighted_ ? edgeWeight : UNWEIGHTED_EDGE_WEIGHT;
    const bool edgeAlreadyExists = (matrix_[startIndex][endIndex] != NO_EDGE);

    matrix_[startIndex][endIndex] = storedWeight;
    if (!directed_){
        matrix_[endIndex][startIndex] = storedWeight;
    }

    if (!edgeAlreadyExists){
        ++edgeCount_;
    }

    return true;
}

bool remove(LabelType start, LabelType end) override{
    const auto startPosition = indexByLabel_.find(start);
    const auto endPosition = indexByLabel_.find(end);
    if (startPosition == indexByLabel_.end() || endPosition == indexByLabel_.end()){
        return false;
    }

    const std::size_t startIndex = startPosition->second;
    const std::size_t endIndex = endPosition->second;
    if (matrix_[startIndex][endIndex] == NO_EDGE){
        return false;
    }

    matrix_[startIndex][endIndex] = NO_EDGE;
    if (!directed_){
        matrix_[endIndex][startIndex] = NO_EDGE;
    }
    --edgeCount_;

    pruneIsolatedVertices({startIndex, endIndex});
    return true;
}

bool hasEdge(LabelType start, LabelType end) const override{
    const auto startPosition = indexByLabel_.find(start);
    const auto endPosition = indexByLabel_.find(end);
    if (startPosition == indexByLabel_.end() || endPosition == indexByLabel_.end()){
        return false;
    }

    return matrix_[startPosition->second][endPosition->second] != NO_EDGE;
}

int getEdgeWeight(LabelType start, LabelType end) const override{
    const auto startPosition = indexByLabel_.find(start);
    const auto endPosition = indexByLabel_.find(end);
    if (startPosition == indexByLabel_.end() || endPosition == indexByLabel_.end()){
        return NO_EDGE;
    }

    return matrix_[startPosition->second][endPosition->second];
}

void depthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    const auto startPosition = indexByLabel_.find(start);
    if (startPosition == indexByLabel_.end()){
        return;
    }

    std::vector<bool> visited(labels_.size(), false);
    depthFirstFrom(startPosition->second, visited, visit);
}

void breadthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    const auto startPosition = indexByLabel_.find(start);
    if (startPosition == indexByLabel_.end())
    {
        return;
    }

    std::vector<bool> visited(labels_.size(), false);
    std::queue<std::size_t> pending;

    visited[startPosition->second] = true;
    pending.push(startPosition->second);

    while (!pending.empty())
    {
        const std::size_t current = pending.front();
        pending.pop();
        visit(labels_[current]);

        for (std::size_t next = 0; next < labels_.size(); ++next){
        if (matrix_[current][next] != NO_EDGE && !visited[next]){
            visited[next] = true;
            pending.push(next);
            }
        }
    }
}

void printAdjacencyMatrix(std::ostream& out) const{
    out << "     ";
    for (std::size_t column = 0; column < labels_.size(); ++column){
        out << std::setw(5) << column;
    }
    out << "\n";

    out << "     ";
    for (const LabelType& label : labels_){
        out << std::setw(5) << label;
    }
    out << "\n";

    for (std::size_t row = 0; row < labels_.size(); ++row){
        out << std::setw(2) << row << " " << std::setw(2) << labels_[row];

        for (std::size_t column = 0; column < labels_.size(); ++column){
        if (matrix_[row][column] == NO_EDGE){
            out << std::setw(5) << (weighted_ ? "INF" : "0");
        }
        else{
            out << std::setw(5) << matrix_[row][column];
            }
        }

        out << "\n";
    }
}

private:
enum{
    NO_EDGE = -1,
    UNWEIGHTED_EDGE_WEIGHT = 1
};


bool directed_;
bool weighted_;
int edgeCount_;
std::vector<LabelType> labels_;
std::vector<std::vector<int>> matrix_;
std::map<LabelType, std::size_t> indexByLabel_;

std::size_t ensureVertex(const LabelType& label){
    const auto position = indexByLabel_.find(label);
    if (position != indexByLabel_.end())
    {
        return position->second;
    }

    const std::size_t newIndex = labels_.size();
    labels_.push_back(label);
    indexByLabel_[label] = newIndex;

    for (auto& row : matrix_){
        row.push_back(NO_EDGE);
    }
    matrix_.push_back(std::vector<int>(labels_.size(), NO_EDGE));

    return newIndex;
}

void depthFirstFrom(std::size_t current, std::vector<bool>& visited, void visit(LabelType&)){
    visited[current] = true;
    visit(labels_[current]);

    for (std::size_t next = 0; next < labels_.size(); ++next){
        if (matrix_[current][next] != NO_EDGE && !visited[next])
        {
            depthFirstFrom(next, visited, visit);
        }
    }
}

bool isIsolated(std::size_t index) const
{
    for (std::size_t other = 0; other < labels_.size(); ++other){
        if (matrix_[index][other] != NO_EDGE || matrix_[other][index] != NO_EDGE){
            return false;
        }
    }
    return true;
}

void pruneIsolatedVertices(std::vector<std::size_t> candidates)
{
    std::sort(candidates.begin(), candidates.end());
    candidates.erase(std::unique(candidates.begin(), candidates.end()), candidates.end());

    for (auto it = candidates.rbegin(); it != candidates.rend(); ++it)
    {
        if (*it < labels_.size() && isIsolated(*it)){
            removeVertexAt(*it);
        }
    }
}

void removeVertexAt(std::size_t index){
    matrix_.erase(matrix_.begin() + static_cast<std::ptrdiff_t>(index));
    for (auto& row : matrix_){
        row.erase(row.begin() + static_cast<std::ptrdiff_t>(index));
    }
    labels_.erase(labels_.begin() + static_cast<std::ptrdiff_t>(index));
    rebuildIndexMap();
}

void rebuildIndexMap()
{
    indexByLabel_.clear();
    for (std::size_t index = 0; index < labels_.size(); ++index){
        indexByLabel_[labels_[index]] = index;
    }
}
};

#endif
