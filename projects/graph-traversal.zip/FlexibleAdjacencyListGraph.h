// Programming Problem 3 (list version) -- configurable adjacency list.
#ifndef FLEXIBLE_ADJACENCY_LIST_GRAPH_H
#define FLEXIBLE_ADJACENCY_LIST_GRAPH_H

#include "FlexibleGraphInterface.h"

#include <algorithm>
#include <cstddef>
#include <forward_list>
#include <map>
#include <ostream>
#include <queue>
#include <vector>

template<class LabelType>
class FlexibleAdjacencyListGraph : public FlexibleGraphInterface<LabelType>{
public:
explicit FlexibleAdjacencyListGraph(bool directed = false, bool weighted = true)
    : directed_(directed),
    weighted_(weighted),
    edgeCount_(0){
}

int getNumVertices() const override{
    return static_cast<int>(labels_.size());
}

int getNumEdges() const override{
    return edgeCount_;
}

bool isDirected() const override{
    return directed_;
}

bool isWeighted() const override{
    return weighted_;
}

void addVertex(LabelType label){
    ensureVertex(label);
}

bool add(LabelType start, LabelType end, int edgeWeight = UNWEIGHTED_EDGE_WEIGHT) override
{
    const std::size_t startIndex = ensureVertex(start);
    const std::size_t endIndex = ensureVertex(end);
    const int storedWeight = weighted_ ? edgeWeight : UNWEIGHTED_EDGE_WEIGHT;
    const bool edgeAlreadyExists = upsertEdge(startIndex, endIndex, storedWeight);

    if (!directed_ && startIndex != endIndex){
        upsertEdge(endIndex, startIndex, storedWeight);
    }

    if (!edgeAlreadyExists){
        ++edgeCount_;
    }

    return true;
}

bool remove(LabelType start, LabelType end) override{
    const auto startPosition = indexByLabel_.find(start);
    const auto endPosition = indexByLabel_.find(end);
    if (startPosition == indexByLabel_.end() || endPosition == indexByLabel_.end()){
        return false;
    }

    const std::size_t startIndex = startPosition->second;
    const std::size_t endIndex = endPosition->second;
    const bool removed = eraseEdge(startIndex, endIndex);
    if (!removed){
        return false;
    }

    if (!directed_ && startIndex != endIndex){
        eraseEdge(endIndex, startIndex);
    }

    --edgeCount_;
    pruneIsolatedVertices({startIndex, endIndex});
    return true;
    }

bool hasEdge(LabelType start, LabelType end) const override{
    const auto startPosition = indexByLabel_.find(start);
    const auto endPosition = indexByLabel_.find(end);
    if (startPosition == indexByLabel_.end() || endPosition == indexByLabel_.end()){
        return false;
    }

    for (const Edge& edge : adjacency_[startPosition->second]){
        if (edge.to == endPosition->second){
            return true;
        }
    }

    return false;
    }

int getEdgeWeight(LabelType start, LabelType end) const override{
    const auto startPosition = indexByLabel_.find(start);
    const auto endPosition = indexByLabel_.find(end);
    if (startPosition == indexByLabel_.end() || endPosition == indexByLabel_.end()){
        return NO_EDGE;
    }

    for (const Edge& edge : adjacency_[startPosition->second]){
        if (edge.to == endPosition->second){
        return edge.weight;
        }
    }

    return NO_EDGE;
}

void depthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    const auto startPosition = indexByLabel_.find(start);
    if (startPosition == indexByLabel_.end())
    {
        return;
    }

    std::vector<bool> visited(labels_.size(), false);
    depthFirstFrom(startPosition->second, visited, visit);
}

void breadthFirstTraversal(LabelType start, void visit(LabelType&)) override{
    const auto startPosition = indexByLabel_.find(start);
    if (startPosition == indexByLabel_.end()){
        return;
    }

    std::vector<bool> visited(labels_.size(), false);
    std::queue<std::size_t> pending;

    visited[startPosition->second] = true;
    pending.push(startPosition->second);

    while (!pending.empty()){
        const std::size_t current = pending.front();
        pending.pop();
        visit(labels_[current]);

        for (const Edge& edge : adjacency_[current])
        {
            if (!visited[edge.to]){
            visited[edge.to] = true;
            pending.push(edge.to);
            }
        }
    }
}

void printAdjacencyList(std::ostream& out) const{
    for (std::size_t index = 0; index < labels_.size(); ++index){
        out << index << " " << labels_[index] << ": ";

        bool first = true;
        for (const Edge& edge : adjacency_[index]){
            if (!first){
            out << " -> ";
        }

            out << labels_[edge.to];
            if (weighted_){
            out << "(" << edge.weight << ")";
        }

        first = false;
        }

        if (first){
            out << "(empty)";
        }

        out << "\n";
    }
}

private:
struct Edge{
    std::size_t to;
    int weight;
};

enum{
    NO_EDGE = -1,
    UNWEIGHTED_EDGE_WEIGHT = 1
};

bool directed_;
bool weighted_;
int edgeCount_;
std::vector<LabelType> labels_;
std::vector<std::forward_list<Edge>> adjacency_;
std::map<LabelType, std::size_t> indexByLabel_;

std::size_t ensureVertex(const LabelType& label){
    const auto position = indexByLabel_.find(label);
    if (position != indexByLabel_.end())
    {
        return position->second;
    }

    const std::size_t newIndex = labels_.size();
    labels_.push_back(label);
    adjacency_.push_back(std::forward_list<Edge>());
    indexByLabel_[label] = newIndex;
    return newIndex;
}

bool upsertEdge(std::size_t from, std::size_t to, int weight){
    auto previous = adjacency_[from].before_begin();
    for (auto current = adjacency_[from].begin(); current != adjacency_[from].end(); ++current){
        if (current->to == to)
        {
        current->weight = weight;
        return true;
        }

        previous = current;
    }

    adjacency_[from].insert_after(previous, {to, weight});
    return false;
}

bool eraseEdge(std::size_t from, std::size_t to)
{
    auto previous = adjacency_[from].before_begin();
    for (auto current = adjacency_[from].begin(); current != adjacency_[from].end(); ++current){
        if (current->to == to){
        adjacency_[from].erase_after(previous);
        return true;
        }

        previous = current;
    }

    return false;
}

void depthFirstFrom(std::size_t current, std::vector<bool>& visited, void visit(LabelType&)){
    visited[current] = true;
    visit(labels_[current]);

    for (const Edge& edge : adjacency_[current]){
        if (!visited[edge.to]){
        depthFirstFrom(edge.to, visited, visit);
        }
    }
}

bool isIsolated(std::size_t index) const{
    if (!adjacency_[index].empty())
    {
        return false;
    }

    for (const auto& edges : adjacency_){
        for (const Edge& edge : edges){
        if (edge.to == index){
            return false;
            }
        }
    }

    return true;
}

void pruneIsolatedVertices(std::vector<std::size_t> candidates){
    std::sort(candidates.begin(), candidates.end());
    candidates.erase(std::unique(candidates.begin(), candidates.end()), candidates.end());

    for (auto it = candidates.rbegin(); it != candidates.rend(); ++it){
        if (*it < labels_.size() && isIsolated(*it)){
        removeVertexAt(*it);
        }
    }
}

void removeVertexAt(std::size_t index)
{
    adjacency_.erase(adjacency_.begin() + static_cast<std::ptrdiff_t>(index));
    labels_.erase(labels_.begin() + static_cast<std::ptrdiff_t>(index));

    for (auto& edges : adjacency_) {
        auto previous = edges.before_begin();
        for (auto current = edges.begin(); current != edges.end(); ){
            if (current->to == index){
            current = edges.erase_after(previous);
        }
        else{
            if (current->to > index){
                --current->to;
            }

            previous = current;
            ++current;
            }
        }
    }

    rebuildIndexMap();
}

void rebuildIndexMap()
{
    indexByLabel_.clear();
    for (std::size_t index = 0; index < labels_.size(); ++index)
    {
        indexByLabel_[labels_[index]] = index;
    }
}
};

#endif
