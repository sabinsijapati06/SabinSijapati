//   Declares the Person class, which represents one entry in
//   the birthday database. Each Person holds a name, birth
//   month, birth day, and birth year.
#ifndef PERSON_
#define PERSON_

#include <iostream>
#include <string>

class Person
{
private:
    std::string name;
    int month;
    int day;
    int year;

public:
    // Constructors
    Person();
    Person(const std::string& theName, int theMonth, int theDay, int theYear);

    // Mutators
    void setName(const std::string& theName);
    void setBirthday(int theMonth, int theDay, int theYear);

    // Accessors
    std::string getName() const;
    int getMonth() const;
    int getDay() const;
    int getYear() const;

    // Comparison operators
    bool operator<(const Person& rightHandSide) const;
    bool operator>(const Person& rightHandSide) const;
    bool operator==(const Person& rightHandSide) const;

    friend std::ostream& operator<<(std::ostream& out, const Person& aPerson);
};

#endif