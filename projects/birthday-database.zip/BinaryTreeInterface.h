//   Interface for the ADT binary tree Listing 15-1

#ifndef BINARY_TREE_INTERFACE_
#define BINARY_TREE_INTERFACE_
#include "NotFoundException.h"

template<class ItemType>
class BinaryTreeInterface
{
public:
   /** Tests whether this binary tree is empty.
    @return True if empty, false otherwise. */
   virtual bool isEmpty() const = 0;

   /** Gets the height of this binary tree.
    @return The number of nodes on the longest root-to-leaf path. */
   virtual int getHeight() const = 0;

   /** Gets the number of nodes in this binary tree.
    @return The total node count. */
   virtual int getNumberOfNodes() const = 0;

   /** Gets the data in the root node.
   @pre  The tree is not empty.
    @return The root's data item. */
   virtual ItemType getRootData() const = 0;

   /** Sets the data in the root. Creates a root node if the tree is empty.
    @param newData  The new data for the root. */
   virtual void setRootData(const ItemType& newData) = 0;

   /** Adds newData to the tree.
    @return True if the addition succeeded. */
   virtual bool add(const ItemType& newData) = 0;

   /** Removes target from the tree.
    @return True if the removal succeeded. */
   virtual bool remove(const ItemType& target) = 0;

   /** Removes all data from the tree. */
   virtual void clear() = 0;

   /** Returns the item in the tree that matches target.
   @post The tree is unchanged.
    @throw NotFoundException if target is not found. */
   virtual ItemType getEntry(const ItemType& target) const = 0;

   /** Tests whether target exists in the tree.
    @return True if found, false otherwise. */
   virtual bool contains(const ItemType& target) const = 0;

   /** Traverses the tree and calls visit() once for each node.
    The three versions visit in preorder, inorder, and postorder. */
   virtual void preorderTraverse (void visit(ItemType&)) const = 0;
   virtual void inorderTraverse  (void visit(ItemType&)) const = 0;
   virtual void postorderTraverse(void visit(ItemType&)) const = 0;

   /** Virtual destructor. */
   virtual ~BinaryTreeInterface() {}

}; // end BinaryTreeInterface
#endif