//   Declares the Database class, which manages a collection of
//   Person objects.

#ifndef DATABASE_H
#define DATABASE_H

#include "BinarySearchTree.h"
#include "Person.h"
#include <string>
#include <vector>

class Database
{
private:
    BinarySearchTree<Person> bst;
    void collectAll(std::vector<Person>& result) const;
    static Person makeSearchKey(const std::string& name);
    static std::string getMonthName(int month);
    static void printDivider();

public:
    Database();
    bool enterPerson(const Person& p);
    bool modifyPerson(const std::string& oldName, const Person& newPerson);
    bool removePerson(const std::string& name);
    bool searchPerson(const std::string& name, Person& found) const;
    void queryByMonth(int month) const;
    void printAll() const;
    void saveToFile(const std::string& fileName) const;
    void loadFromFile(const std::string& fileName);
};

#endif