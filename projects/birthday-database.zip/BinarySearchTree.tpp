//   Implements the BinarySearchTree class template.
#include "BinarySearchTree.h"
template<class ItemType>
std::shared_ptr<BinaryNode<ItemType>> BinarySearchTree<ItemType>::placeNode(
   std::shared_ptr<BinaryNode<ItemType>> subTreePtr,
   std::shared_ptr<BinaryNode<ItemType>> newNode){
   if (subTreePtr == nullptr)
      return newNode;

   if (subTreePtr->getItem() > newNode->getItem()){
      auto tempPtr = placeNode(subTreePtr->getLeftChildPtr(), newNode);
      subTreePtr->setLeftChildPtr(tempPtr);
   }
   else{
      auto tempPtr = placeNode(subTreePtr->getRightChildPtr(), newNode);
      subTreePtr->setRightChildPtr(tempPtr);
   }
   return subTreePtr;
}

template<class ItemType>
std::shared_ptr<BinaryNode<ItemType>> BinarySearchTree<ItemType>::removeValue(
   std::shared_ptr<BinaryNode<ItemType>> subTreePtr,
   const ItemType target, bool& isSuccessful){
   if (subTreePtr == nullptr){
      isSuccessful = false;
      return nullptr;
   }
   if (subTreePtr->getItem() == target){
      subTreePtr   = removeNode(subTreePtr);
      isSuccessful = true;
   }
   else if (subTreePtr->getItem() > target){
      auto tempPtr = removeValue(subTreePtr->getLeftChildPtr(), target, isSuccessful);
      subTreePtr->setLeftChildPtr(tempPtr);
   }
   else{
      auto tempPtr = removeValue(subTreePtr->getRightChildPtr(), target, isSuccessful);
      subTreePtr->setRightChildPtr(tempPtr);
   }
   return subTreePtr;
}

template<class ItemType>
std::shared_ptr<BinaryNode<ItemType>> BinarySearchTree<ItemType>::removeNode(
   std::shared_ptr<BinaryNode<ItemType>> nodePtr){
   // Case 1: leaf node
   if (nodePtr->isLeaf())
      return nullptr;

   // Case 2: one child
   if (nodePtr->getLeftChildPtr() == nullptr)
      return nodePtr->getRightChildPtr();
   if (nodePtr->getRightChildPtr() == nullptr)
      return nodePtr->getLeftChildPtr();

   // Case 3: two children
   ItemType successorValue;
   auto tempPtr = removeLeftmostNode(nodePtr->getRightChildPtr(), successorValue);
   nodePtr->setRightChildPtr(tempPtr);
   nodePtr->setItem(successorValue);
   return nodePtr;
}

template<class ItemType>
std::shared_ptr<BinaryNode<ItemType>> BinarySearchTree<ItemType>::removeLeftmostNode(
   std::shared_ptr<BinaryNode<ItemType>> nodePtr,
   ItemType& inorderSuccessor){
   if (nodePtr->getLeftChildPtr() == nullptr){
      inorderSuccessor = nodePtr->getItem();
      return removeNode(nodePtr);
   }
   auto tempPtr = removeLeftmostNode(nodePtr->getLeftChildPtr(), inorderSuccessor);
   nodePtr->setLeftChildPtr(tempPtr);
   return nodePtr;
}

template<class ItemType>
std::shared_ptr<BinaryNode<ItemType>> BinarySearchTree<ItemType>::findNode(
   std::shared_ptr<BinaryNode<ItemType>> treePtr,
   const ItemType& target) const{
   if (treePtr == nullptr)
      return nullptr;           // not found

   if (treePtr->getItem() == target)
      return treePtr;           // found

   if (treePtr->getItem() > target)
      return findNode(treePtr->getLeftChildPtr(),  target);  // go left
   else
      return findNode(treePtr->getRightChildPtr(), target);  // go right
}

template<class ItemType>
BinarySearchTree<ItemType>::BinarySearchTree() {}

template<class ItemType>
BinarySearchTree<ItemType>::BinarySearchTree(const ItemType& rootItem)
   : BinaryNodeTree<ItemType>(rootItem) {}

template<class ItemType>
BinarySearchTree<ItemType>::BinarySearchTree(
   const BinarySearchTree<ItemType>& tree)
   : BinaryNodeTree<ItemType>(tree) {}

template<class ItemType>
BinarySearchTree<ItemType>::~BinarySearchTree() {}


template<class ItemType>
bool BinarySearchTree<ItemType>::add(const ItemType& newEntry){
   auto newNodePtr  = std::make_shared<BinaryNode<ItemType>>(newEntry);
   this->rootPtr    = placeNode(this->rootPtr, newNodePtr);
   return true;
}

template<class ItemType>
bool BinarySearchTree<ItemType>::remove(const ItemType& target){
   bool isSuccessful = false;
   this->rootPtr = removeValue(this->rootPtr, target, isSuccessful);
   return isSuccessful;
}

template<class ItemType>
ItemType BinarySearchTree<ItemType>::getEntry(const ItemType& anEntry) const{
   auto nodePtr = findNode(this->rootPtr, anEntry);
   if (nodePtr != nullptr)
      return nodePtr->getItem();
   throw NotFoundException("Entry not found in tree.");
}

template<class ItemType>
bool BinarySearchTree<ItemType>::contains(const ItemType& anEntry) const{
   return findNode(this->rootPtr, anEntry) != nullptr;
}

template<class ItemType>
BinarySearchTree<ItemType>& BinarySearchTree<ItemType>::operator=(
   const BinarySearchTree<ItemType>& rightHandSide){
   if (this != &rightHandSide)
      BinaryNodeTree<ItemType>::operator=(rightHandSide);
   return *this;
}