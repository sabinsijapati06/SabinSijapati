//   Implements the Database class.

#include "Database.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <stdexcept>

static std::vector<Person> traversalBuffer;

static void collectVisitor(Person& p){
    traversalBuffer.push_back(p);
}

void Database::collectAll(std::vector<Person>& result) const{
    traversalBuffer.clear();
    bst.inorderTraverse(collectVisitor);   // visits all nodes A-Z
    result = traversalBuffer;
}

Person Database::makeSearchKey(const std::string& name){
    return Person(name, 1, 1, 2000);
}

std::string Database::getMonthName(int month){
    static const std::string names[] = {
        "", "January", "February", "March",    "April",
        "May",       "June",      "July",       "August",
        "September", "October",   "November",   "December"
    };
    if (month >= 1 && month <= 12)
        return names[month];
    return "Unknown";
}

void Database::printDivider(){
    std::cout << "  ------------------------------------------\n";
}

Database::Database(){}

// enterPerson
bool Database::enterPerson(const Person& p){
    if (bst.contains(p))
        return false;   // name already taken

    bst.add(p);
    return true;
}

// modifyPerson
bool Database::modifyPerson(const std::string& oldName, const Person& newPerson){
    Person oldKey = makeSearchKey(oldName);
    if (!bst.contains(oldKey))
        return false;

    bool nameChanging = !(oldKey == newPerson);
    if (nameChanging && bst.contains(newPerson)){
        std::cout << "  \"" << newPerson.getName()
                << "\" already exists in the database.\n"
                << "  Modification was not applied.\n";
        return false;
    }

    bst.remove(oldKey);
    bst.add(newPerson);
    return true;
}

// removePerson
bool Database::removePerson(const std::string& name){
    Person key = makeSearchKey(name);

    if (!bst.contains(key))
        return false;

    bst.remove(key);
    return true;
}

// searchPerson
bool Database::searchPerson(const std::string& name, Person& found) const{
    Person key = makeSearchKey(name);

    if (!bst.contains(key))
        return false;

    found = bst.getEntry(key);
    return true;
}

// queryByMonth
void Database::queryByMonth(int month) const{
    if (month < 1 || month > 12){
        std::cout << "\n  Please enter a month between 1 and 12.\n";
        return;
    }

    std::vector<Person> everyone;
    collectAll(everyone);

    std::cout << "\n  People born in " << getMonthName(month) << ":\n";
    printDivider();

    int matchCount = 0;
    for (const Person& p : everyone){
        if (p.getMonth() == month){
            std::cout << "  " << p << "\n";
            matchCount++;
        }
    }

    if (matchCount == 0)
        std::cout << "  No records found for " << getMonthName(month) << ".\n";
    else{
        printDivider();
        std::cout << "  " << matchCount << " record(s) found.\n";
    }
}

// printAll
void Database::printAll() const{
    if (bst.isEmpty()){
        std::cout << "\n  The database is empty. "
                << "Use option 1 to add people.\n";
        return;
    }

    int total  = bst.getNumberOfNodes();
    int height = bst.getHeight();
    int optMin = static_cast<int>(std::ceil(std::log2(total + 1)));

    std::cout << "   All Records  (" << total << " total)\n";
    std::cout << "   BST height: " << height
            << "  |  Optimal minimum: " << optMin << "\n";

    std::vector<Person> everyone;
    collectAll(everyone);

    int i = 1;
    for (const Person& p : everyone){
        std::cout << "  " << std::setw(3) << i << ". " << p << "\n";
        i++;
    }

    printDivider();
}

// saveToFile
void Database::saveToFile(const std::string& fileName) const{
    std::ofstream outFile(fileName);

    if (!outFile){
        std::cout << "  Could not open \"" << fileName
                << "\" for writing.\n";
        return;
    }

    outFile << "# Birthday Database - saved by program\n";
    outFile << "# Format: name,birth_month,birth_day,birth_year\n";

    std::vector<Person> everyone;
    collectAll(everyone);   // inorder = alphabetical order in file

    for (const Person& p : everyone){
        outFile << p.getName()  << ","
                << p.getMonth() << ","
                << p.getDay()   << ","
                << p.getYear()  << "\n";
    }

    outFile.close();
    std::cout << "  " << everyone.size()
            << " record(s) written to \"" << fileName << "\".\n";
}

// loadFromFile
// Reads a CSV file and adds each record to the BST.
void Database::loadFromFile(const std::string& fileName){
    std::ifstream inFile(fileName);

    if (!inFile){
        std::cout << "  Could not open \"" << fileName
                << "\". Please check the file name.\n";
        return;
    }

    int added   = 0;
    int skipped = 0;
    int lineNum = 0;
    std::string line;

    while (std::getline(inFile, line)){
        lineNum++;

        // Skip blank lines and comment lines.
        if (line.empty() || line[0] == '#')
            continue;

        try{
            // Parse: name,month,day,year
            std::istringstream ss(line);
            std::string token;
            std::string pName;
            int pMonth = 0, pDay = 0, pYear = 0;

            if (std::getline(ss, token, ',')) pName  = token;
            if (std::getline(ss, token, ',')) pMonth = std::stoi(token);
            if (std::getline(ss, token, ',')) pDay   = std::stoi(token);
            if (std::getline(ss, token, ',')) pYear  = std::stoi(token);

            if (pName.empty()){
                std::cout << "  Line " << lineNum
                        << ": empty name -- skipped.\n";
                skipped++;
                continue;
            }

            Person p(pName, pMonth, pDay, pYear);

            if (bst.contains(p)){
                std::cout << "  \"" << pName
                        << "\" already exists -- skipped.\n";
                skipped++;
            }
            else{
                bst.add(p);
                added++;
            }
        }
        catch (const std::exception& e){
            std::cout << "  Line " << lineNum
                    << ": could not parse record -- skipped.\n";
            skipped++;
        }
    }

    inFile.close();

    std::cout << "  " << added
            << " record(s) loaded from \"" << fileName << "\"";
    if (skipped > 0)
        std::cout << " (" << skipped << " skipped)";
    std::cout << ".\n";
}