// Name : Sabin Sijapati
// Date : 04/05/2026
// Program : Topic 8 – Binary Trees
//   This is the main driver for the Birthday Database program.
//   It presents a numbered menu and reads the user's choice in
//   a do-while loop until they choose to exit.

#include <iostream>
#include <limits>
#include "Database.h"
using namespace std;

// displayMenu
void displayMenu(){
    cout << "\n===== Birthday Database Menu =====" << endl;
    cout << "1. Enter a new person" << endl;
    cout << "2. Modify a person" << endl;
    cout << "3. Remove a person" << endl;
    cout << "4. Search for a person" << endl;
    cout << "5. Query by birth month" << endl;
    cout << "6. Print everyone" << endl;
    cout << "7. Save to file" << endl;
    cout << "8. Load from file" << endl;
    cout << "9. Exit" << endl;
    cout << "Enter your choice: ";
}

// main
int main(){
    Database db;
    int choice;

    do{
        displayMenu();
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (choice == 1){
            string name;
            int month, day, year;
            cout << "Enter name: ";
            getline(cin, name);
            cout << "Enter birth month: ";
            cin >> month;
            cout << "Enter birth day: ";
            cin >> day;
            cout << "Enter birth year: ";
            cin >> year;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if (db.enterPerson(Person(name, month, day, year)))
                cout << "Person added successfully." << endl;
            else
                cout << "That name already exists." << endl;
        }
        else if (choice == 2){
            string oldName, newName;
            int month, day, year;
            cout << "Enter the name to modify: ";
            getline(cin, oldName);
            cout << "Enter new name: ";
            getline(cin, newName);
            cout << "Enter new birth month: ";
            cin >> month;
            cout << "Enter new birth day: ";
            cin >> day;
            cout << "Enter new birth year: ";
            cin >> year;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if (db.modifyPerson(oldName, Person(newName, month, day, year)))
                cout << "Person modified successfully." << endl;
            else
                cout << "Person not found." << endl;
        }
        else if (choice == 3){
            string name;
            cout << "Enter the name to remove: ";
            getline(cin, name);
            if (db.removePerson(name))
                cout << "Person removed successfully." << endl;
            else
                cout << "Person not found." << endl;
        }
        else if (choice == 4){
            string name;
            Person found;
            cout << "Enter the name to search: ";
            getline(cin, name);
            if (db.searchPerson(name, found))
                cout << found << endl;
            else
                cout << "Person not found." << endl;
        }
        else if (choice == 5){
            int month;
            cout << "Enter a month (1-12): ";
            cin >> month;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            db.queryByMonth(month);
        }
        else if (choice == 6){
            db.printAll();
        }
        else if (choice == 7){
            string fileName;
            cout << "Enter file name to save: ";
            getline(cin, fileName);
            db.saveToFile(fileName);
            cout << "Data saved." << endl;
        }
        else if (choice == 8){
            string fileName;
            cout << "Enter file name to load: ";
            getline(cin, fileName);
            db.loadFromFile(fileName);
            cout << "Data loaded." << endl;
        }
        else if (choice == 9){
            cout << "Exiting program." << endl;
        }
        else{
            cout << "Invalid choice. Try again." << endl;
        }

    } while (choice != 9);

    return 0;
}