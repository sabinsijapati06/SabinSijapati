//   Implements the Person class declared in Person.h.
//   All comparison operators compare the 'name' field only,
//   which is what allows the BST to order Person objects
//   alphabetically by name.

#include "Person.h"

// Default constructor 
Person::Person() : name(""), month(1), day(1), year(2000){
}

// Parameterized constructor
Person::Person(const std::string& theName, int theMonth, int theDay, int theYear)
    : name(theName), month(theMonth), day(theDay), year(theYear){
}

// Mutators
void Person::setName(const std::string& theName){
    name = theName;
}

void Person::setBirthday(int theMonth, int theDay, int theYear){
    month = theMonth;
    day   = theDay;
    year  = theYear;
}

// Accessors
std::string Person::getName()  const { return name;  }
int         Person::getMonth() const { return month; }
int         Person::getDay()   const { return day;   }
int         Person::getYear()  const { return year;  }

// Comparison operators
bool Person::operator<(const Person& rightHandSide) const{
    return name < rightHandSide.name;
}

bool Person::operator>(const Person& rightHandSide) const{
    return name > rightHandSide.name;
}

bool Person::operator==(const Person& rightHandSide) const{
    return name == rightHandSide.name;
}

std::ostream& operator<<(std::ostream& out, const Person& aPerson){
    out << "Name: " << aPerson.name
        << " | Birthday: " << aPerson.month << "/"
        << aPerson.day << "/" << aPerson.year;
    return out;
}