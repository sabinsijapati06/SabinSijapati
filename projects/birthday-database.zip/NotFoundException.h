//   Exception class thrown by getEntry() when a search target
//   is not found in the binary tree.

#ifndef NOT_FOUND_EXCEPTION_
#define NOT_FOUND_EXCEPTION_

#include <stdexcept>
#include <string>

class NotFoundException : public std::runtime_error
{
public:
   explicit NotFoundException(const std::string& message = "")
      : std::runtime_error("Not Found Exception: " + message) {}
};

#endif