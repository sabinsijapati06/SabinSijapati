Birthday Database
Coursework by Sabin Sijapati. Original course code; retain attribution in source files.
Add, edit, remove, and search records; query birthdays by month; import and export CSV-style records.
