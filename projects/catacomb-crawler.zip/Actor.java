import java.util.Random;

/**
 * representing characters in the Catacomb Crawler game
 */
public class Actor {
    // Private attributes
    private String name;
    private int health = 100;
    private int maxDamage = 10;
    private int row = 0;
    private int col = 0;

    public Actor() {
        this.name = "";
        this.health = health;
        this.maxDamage = maxDamage;
        this.row = row;
        this.col = col;
    }
    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getMaxDamage() {
        return maxDamage;
    }

    public void setMaxDamage(int maxDamage) {
        this.maxDamage = maxDamage;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    /**
     * check in if the actor is alive
     * 
     * @return true if health is greater than 0
     */
    public boolean alive() {
        return health > 0;
    }

    /**
     * check in if the actor has escaped the catacomb
     * 
     * @param dungeonSize size of the catacomb
     * @return true if actor is in the bottom-right room otherwise false
     */
    public boolean hasEscaped(int dungeonSize) {
        return row == dungeonSize - 1 && col == dungeonSize - 1;
    }

    /**
     * Check in if this actor is in the same room as another actor
     * @param other another actor to compare location
     * @return true if in the same room otherwise false
     */
    public boolean inSameRoom(Actor other) {
        return this.row == other.getRow() && this.col == other.getCol();
    }

    /**
     * Check in if this actor is in an adjacent room to another actor
     * @param other another actor to compare location
     * @return true if in an adjacent room otherwise false
     */
    public boolean inAdjRoom(Actor other) {
        return Math.abs(this.row - other.getRow()) + Math.abs(this.col - other.getCol()) == 1;
    }

    /**
     * Attack another actor and reduce health
     * @param other actor gets attack
     */
    public void hit(Actor other) {
        Random random = new Random();
        int damage = random.nextInt(maxDamage) + 1;
        other.setHealth(other.getHealth() - damage);
        System.out.println(this.name + " hits " + other.getName() + " for " + damage);
    }

    /**
     * Move the actor in a different direction
     * @param direction direction to move north, south, east, west
     * @param dungeonSize size of the catacomb
     * @return true if move is valid otherwise false
     */
    public boolean move(String direction, int dungeonSize) {
        int originalRow = row;
        int originalCol = col;

        switch (direction.toLowerCase()) {
            case "north":
                row--;
                break;
            case "south":
                row++;
                break;
            case "east":
                col++;
                break;
            case "west":
                col--;
                break;
            case "n":
                row--;
                break;
            case "s":
                row++;
                break;
            case "e":
                col++;
                break;
            case "w":
                col--;
                break;
            default:
                return false;
        }

        // Check if move is valid
        if (row < 0 || row >= dungeonSize || col < 0 || col >= dungeonSize) {
            row = originalRow;
            col = originalCol;
            return false;
        }
        return true;
    }

    /**
     * String representation of the actor
     * @return actor details as a string
     */
    @Override
    public String toString() {
        return name + " at " + row + ", " + col + " with " + health + " health ";
    }
}