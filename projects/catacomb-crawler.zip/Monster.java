/**
 * Monster class extending the Actor class for enemies
 */
public class Monster extends Actor {
    /**
     * making up monster
     * @param name monster name
     */
    public Monster(String name) {
        super();
        setName(name);
        setMaxDamage(5);
    }
}