import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Catacomb{
    /**
     * Valid dungeon size from the user
     * @param scnr input scanner
     * @return dungeon size between 5 and 10
     */
    public static int getDungeonSize(Scanner scnr) {
        while (true) {
            System.out.print("How wide of a catacomb do you want to face (5-10)? ");
            try {
                int size = Integer.parseInt(scnr.nextLine());
                if (size >= 5 && size <= 10) {
                    return size;
                }
                System.out.println("That is not a valid catacomb size ");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number ");
            }
        }
    }

    /**
     * Create the hero character
     * @param scnr input scanner
     * @return hero character
     */
    public static Hero makeActor(Scanner scnr) {
        System.out.print("What is your name heroic adventurer? ");
        String name = scnr.nextLine();
        return new Hero(name);
    }

    /**
     * Create monsters for the catacomb
     * @param dungeonSize size of the catacomb
     * @return list of monsters
     */
    public static ArrayList<Monster> makeMonsters(int dungeonSize) {
        Random rand = new Random();
        int monsterCount = dungeonSize * dungeonSize / 6;
        ArrayList<Monster> monsters = new ArrayList<>();

        for (int i = 1; i <= monsterCount; i++) {
            Monster monster = new Monster("Monster " + i);
            do {
                monster.setRow(rand.nextInt(dungeonSize));
                monster.setCol(rand.nextInt(dungeonSize));
            } while (monster.getRow() == 0 && monster.getCol() == 0);  // avoid starting in hero room
        
            monsters.add(monster);
        }

        return monsters;
    }

    /**
     * Count nearby monsters in adjacent rooms
     * @param hero  hero character
     * @param monsters list of monsters
     * @return number of monsters in adjacent rooms
     */
    public static int countMonsters(Hero hero, ArrayList<Monster> monsters) {
        int count = 0;
        for (Monster monster : monsters) {
            if (hero.inAdjRoom(monster)) {
            count++;
            }
        }
        return count;
    }

    /**
     * fighting between hero and monsters
     * @param hero hero character
     * @param monsters list of monsters
     */
    public static void fight(Hero hero, ArrayList<Monster> monsters) {
        // find monsters in the same room
        ArrayList<Monster> roomMonsters = new ArrayList<>();
        for (Monster monster : monsters) {
            if (hero.inSameRoom(monster)) {
                roomMonsters.add(monster);
            }
        }

        // fight each monster
        for (Monster monster : roomMonsters) {
            System.out.println(hero + " versus " + monster);
            
            while (hero.alive() && monster.alive()) {
                hero.hit(monster);
                if (!monster.alive()) {
                System.out.println(monster.getName() + " has been defeated ");
                monsters.remove(monster);
                break;
                }

                monster.hit(hero);
                if (!hero.alive()) {
                System.out.println("Game Over " + hero.getName() + " has died ");
                return;
                }
            }
        }
    }

    /**
     * player movement
     * @param hero hero character
     * @param monsters  list of monsters
     * @param dungeonSize size of the catacomb
     * @param scnr  input scanner
     * @return true if game should continue otherwiser false and over
     */
    public static boolean move(Hero hero, ArrayList<Monster> monsters, int dungeonSize, Scanner scnr) {
        // reduce health for movement
        hero.setHealth(hero.getHealth() - 2);

        // check for healing potion
        Random rand = new Random();
        if (rand.nextInt(10) == 0) {  // 10% chance of a healing potion
            int heal = 20;
            hero.setHealth(Math.min(hero.getHealth() + heal, 100));
            System.out.println("You found a healing potion and restored " + heal + " health ");
        }

        // count nearby monsters
        int nearbyMonsters = countMonsters(hero, monsters);
        System.out.println(hero);
        System.out.println("You smell " + nearbyMonsters + " monsters nearby ");

        // Get movement direction
        while (true) {
            System.out.print("Which way do you want to go north, south, east, west? ");
            String direction = scnr.nextLine().toLowerCase();

            if (hero.move(direction, dungeonSize)) {
            // check if monsters in new room
            fight(hero, monsters);

                // check in for escape
                if (hero.hasEscaped(dungeonSize)) {
                System.out.println("You have escaped the catacomb ");
                return false;
                }

                // check if hero is alive
                if (!hero.alive()) {
                return false;
                }

                return true;
            } else {
                System.out.println("You can't move that way ");
            }
        }
    }

    /**
     * map for catacomb 
     */
    public static char[][] putMap(int dungeonSize, Hero hero, ArrayList<Monster> monsters) {
        char[][] map = new char[dungeonSize][dungeonSize];
        for (int i = 0; i < dungeonSize; i++) {
            for (int j = 0; j < dungeonSize; j++) {
                map[i][j] = ' ';
            }
        }
        map[hero.getRow()][hero.getCol()] = 'H';
        for (Monster monster : monsters) {
            if (monster.alive()) {
            map[monster.getRow()][monster.getCol()] = 'M';
            }
        }
        map[dungeonSize - 1][dungeonSize - 1] = 'E';
        return map;
    }

    /**
     * new map with update
     */
    public static void newMap(char[][] map, Hero hero, ArrayList<Monster> monsters) {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                map[i][j] = ' ';
            }
        }
        map[hero.getRow()][hero.getCol()] = 'H';
        for (Monster monster : monsters) {
            if (monster.alive()) {
                map[monster.getRow()][monster.getCol()] = 'M';
            }
        }
        map[map.length - 1][map.length - 1] = 'E';
    }

    /**
     * showing the map
     */
    public static void map(char[][] map) {
        System.out.println("Catacomb Map:");
        for (char[] map1 : map) {
            for (int j = 0; j < map1.length; j++) {
                System.out.print("(" + map1[j] + ")");
            }
            System.out.println();
        }
    }
}