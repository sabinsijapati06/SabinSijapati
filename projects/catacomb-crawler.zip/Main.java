import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    /**
     * Main game method
     */
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Good Luck, adventure");

        // get dungeon size
        int dungeonSize = Catacomb.getDungeonSize(scnr);

        // create hero
        Hero hero = Catacomb.makeActor(scnr);

        // create monsters
        ArrayList<Monster> monsters = Catacomb.makeMonsters(dungeonSize);

        // put the map
        char[][] map = Catacomb.putMap(dungeonSize, hero, monsters);

        // game loop
        while (hero.alive() && !hero.hasEscaped(dungeonSize)) {
            Catacomb.map(map);
            if (!Catacomb.move(hero, monsters, dungeonSize, scnr)) {
                break;
            }
            Catacomb.newMap(map, hero, monsters);
        }

        scnr.close();
    }
}