/**
 * Hero class extending the actor class for the player character
 */
public class Hero extends Actor {
    /**
     * making up hero
     * @param name hero name
     */
    public Hero(String name) {
        super();
        setName(name);
        setMaxDamage(10);
        setRow(0);
        setCol(0);
        System.out.println("Hero " + name + " has entered the catacomb ");
    }
}