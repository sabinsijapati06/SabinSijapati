Catacomb Crawler
Coursework by Sabin Sijapati. Original course code; retain attribution in source files.
Uses Actor, Hero, and Monster classes, bounded movement, random combat, healing, and a text-based map.
